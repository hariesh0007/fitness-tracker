# Installation
> `npm install --save @types/d3-shape`

# Summary
This package contains type definitions for d3-shape (https://github.com/d3/d3-shape/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-shape.

### Additional Details
 * Last updated: Mon, 06 Jan 2025 00:46:49 GMT
 * Dependencies: [@types/d3-path](https://npmjs.com/package/@types/d3-path)

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [Nathan Bierema](https://github.com/Methuselah96), and [Fil](https://github.com/Fil).
