import {
  require_react
} from "./chunk-HSUUC2QV.js";
import "./chunk-DC5AMYBS.js";
export default require_react();
