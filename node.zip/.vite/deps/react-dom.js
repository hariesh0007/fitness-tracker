import {
  require_react_dom
} from "./chunk-A7ECLLTJ.js";
import "./chunk-HSUUC2QV.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
