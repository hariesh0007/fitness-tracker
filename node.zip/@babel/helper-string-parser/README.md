# @babel/helper-string-parser

> A utility package to parse strings

See our website [@babel/helper-string-parser](https://babeljs.io/docs/babel-helper-string-parser) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-string-parser
```

or using yarn:

```sh
yarn add @babel/helper-string-parser
```
